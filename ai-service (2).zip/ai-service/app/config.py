import os


# AI service key required by backend proxy to call this service
AI_SERVICE_KEY = os.environ.get("AI_SERVICE_KEY") or os.environ.get("AI_KEY") or ""

# Local model configuration
# MODEL_LOCAL_ENABLED: set to 'true' to force local-only inference
MODEL_LOCAL_ENABLED = os.environ.get("MODEL_LOCAL_ENABLED", "true").lower() in ("1", "true", "yes")
MODEL_NAME = os.environ.get("MODEL_NAME") or os.environ.get("AI_MODEL_NAME") or "gpt2"
# Local directory where the model will be downloaded (download_model.py writes here)
MODEL_DIR = os.environ.get("MODEL_DIR") or os.environ.get("MODEL_PATH") or f"/app/models/{MODEL_NAME}"

# Directory where retrieval index and docs are stored
DATA_DIR = os.environ.get("AI_DATA_DIR") or os.environ.get("DATA_DIR") or "/app/data"

# Optional PEFT adapter path (local path where adapter is saved)
AI_PEFT_ADAPTER = os.environ.get("AI_PEFT_ADAPTER") or os.environ.get("PEFT_ADAPTER") or None

# Other runtime tuning
MAX_GENERATION_TOKENS = int(os.environ.get("MAX_GENERATION_TOKENS", "256"))
# Enforce presence of API key in production (set REQUIRE_API_KEY=false to disable)
REQUIRE_API_KEY = os.environ.get("REQUIRE_API_KEY", "true").lower() in ("1", "true", "yes")

# Generation timeout (seconds)
AI_GEN_TIMEOUT = int(os.environ.get("AI_GEN_TIMEOUT", "50"))

# Rate limiting (requests per window)
AI_RATE_LIMIT = int(os.environ.get("AI_RATE_LIMIT", "20"))
AI_RATE_WINDOW = int(os.environ.get("AI_RATE_WINDOW", "60"))

# Max input tokens to send to model (conservative default for GPT-2 context ~1024)
AI_MAX_INPUT_TOKENS = int(os.environ.get("AI_MAX_INPUT_TOKENS", "800"))

# Proxy/backend timeout for requests to this service
AI_PROXY_TIMEOUT_MS = int(os.environ.get("AI_PROXY_TIMEOUT_MS", "120000"))
