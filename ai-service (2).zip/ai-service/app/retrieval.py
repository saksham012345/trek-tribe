import os
import json
import pickle
from typing import List, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

from . import config

# Simple TF-IDF retrieval module
DATA_DIR = config.DATA_DIR
INDEX_PATH = os.path.join(DATA_DIR, 'tfidf_index.pkl')
DOCS_PATH = os.path.join(DATA_DIR, 'tfidf_docs.json')

# Runtime flag
RETRIEVAL_INDEX_LOADED = False


def ensure_data_dir():
    d = os.path.dirname(INDEX_PATH)
    if not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def load_index():
    if not os.path.exists(INDEX_PATH) or not os.path.exists(DOCS_PATH):
        return None, None, None
    with open(INDEX_PATH, 'rb') as f:
        vec, matrix = pickle.load(f)
    with open(DOCS_PATH, 'r', encoding='utf-8') as f:
        docs = json.load(f)
    global RETRIEVAL_INDEX_LOADED
    RETRIEVAL_INDEX_LOADED = True
    return vec, matrix, docs


def save_index(vectorizer, tfidf_matrix, docs: List[dict]):
    ensure_data_dir()
    with open(INDEX_PATH, 'wb') as f:
        pickle.dump((vectorizer, tfidf_matrix), f)
    with open(DOCS_PATH, 'w', encoding='utf-8') as f:
        json.dump(docs, f, ensure_ascii=False, indent=2)
    global RETRIEVAL_INDEX_LOADED
    RETRIEVAL_INDEX_LOADED = True


def retrieve(query: str, top_k: int = 3) -> List[Tuple[float, dict]]:
    """Return list of (score, doc) tuples."""
    vec, matrix, docs = load_index()
    if vec is None or matrix is None or docs is None:
        return []

    q_vec = vec.transform([query])
    # cosine similarity via linear_kernel is efficient for TF-IDF
    sim = linear_kernel(q_vec, matrix).flatten()
    idxs = sim.argsort()[::-1][:top_k]
    results = []
    for i in idxs:
        if sim[i] <= 0:
            continue
        results.append((float(sim[i]), docs[i]))
    return results


def build_index_from_texts(texts: List[str], metadata: List[dict], **kwargs):
    """Build TF-IDF index from a list of texts and corresponding metadata.

    `metadata` is a list of dicts (e.g., {"source": path, "excerpt": text}).
    """
    if len(texts) == 0:
        raise ValueError('No texts provided to build index')

    vectorizer = TfidfVectorizer(stop_words='english', max_df=0.9, min_df=1, **kwargs)
    tfidf = vectorizer.fit_transform(texts)

    docs = []
    for md, txt in zip(metadata, texts):
        entry = dict(md)
        entry.setdefault('text', txt)
        docs.append(entry)

    save_index(vectorizer, tfidf, docs)
    return vectorizer, tfidf, docs
