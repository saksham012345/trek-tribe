import os
import sys
import json
from pathlib import Path
from app.retrieval import build_index_from_texts


def gather_text_files(root: Path, patterns=None):
    patterns = patterns or ['**/*.md', '**/*.txt', '**/*.mdx', '**/*.html', '**/*.tsx', '**/*.ts', '**/*.jsx', '**/*.js']
    files = []
    for p in patterns:
        files.extend(list(root.glob(p)))
    # Filter duplicates and non-files
    files = [f for f in sorted(set(files)) if f.is_file()]
    return files


def read_text(path: Path) -> str:
    try:
        text = path.read_text(encoding='utf-8')
        return text
    except Exception:
        try:
            return path.read_text(encoding='latin-1')
        except Exception:
            return ''


def split_into_passages(text: str, max_chars=1000):
    text = text.strip()
    if not text:
        return []
    passages = []
    i = 0
    while i < len(text):
        chunk = text[i:i+max_chars]
        passages.append(chunk.strip())
        i += max_chars
    return passages


def main(repo_root: str = '.'):
    root = Path(repo_root)
    sources = []
    texts = []
    metas = []

    # Directories to include
    targets = [root / 'docs', root / 'web' / 'src' / 'pages']
    # Also include top-level README files
    top_files = [root / 'README.md', root / 'API_DOCUMENTATION.md']

    for tf in top_files:
        if tf.exists():
            files = [tf]
        else:
            files = []
        for f in files:
            t = read_text(f)
            for p in split_into_passages(t):
                texts.append(p)
                metas.append({'source': str(f.relative_to(root))})

    for target in targets:
        if not target.exists():
            continue
        files = gather_text_files(target)
        for f in files:
            t = read_text(f)
            if not t.strip():
                continue
            for p in split_into_passages(t):
                texts.append(p)
                metas.append({'source': str(f.relative_to(root))})

    if not texts:
        print('No documents found to index. Checked:', targets, top_files)
        return 1

    print(f'Indexing {len(texts)} passages from site docs...')
    build_index_from_texts(texts, metas)
    print('Index built and saved under ai-service/data/')
    return 0


if __name__ == '__main__':
    root = sys.argv[1] if len(sys.argv) > 1 else '.'
    sys.exit(main(root))
