#!/usr/bin/env python3
"""Download a Hugging Face model and save to a local directory.

Usage:
  MODEL_NAME=gpt2-medium python download_model.py
  or set MODEL_DIR to override where to save
"""
import os
import sys
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("download_model")

MODEL = os.environ.get("MODEL_NAME") or os.environ.get("AI_MODEL_NAME") or "gpt2-medium"
MODEL_DIR = os.environ.get("MODEL_DIR") or os.environ.get("MODEL_PATH") or f"/app/models/{MODEL}"


def main():
    try:
        from transformers import AutoTokenizer, AutoModelForCausalLM
    except Exception as e:
        logger.error("transformers not installed: %s", e)
        sys.exit(2)

    dest = Path(MODEL_DIR)
    dest.mkdir(parents=True, exist_ok=True)

    logger.info("Downloading tokenizer for %s -> %s", MODEL, dest)
    tokenizer = AutoTokenizer.from_pretrained(MODEL, use_fast=True)
    tokenizer.save_pretrained(dest)

    logger.info("Downloading model weights for %s -> %s", MODEL, dest)
    model = AutoModelForCausalLM.from_pretrained(MODEL)
    model.save_pretrained(dest)

    logger.info("Model downloaded to %s", dest)


if __name__ == "__main__":
    main()
