from fastapi import FastAPI, Request, Header, HTTPException
from pydantic import BaseModel
import logging
from typing import Optional

from .config import AI_SERVICE_KEY, MODEL_NAME, MODEL_LOCAL_ENABLED, MODEL_DIR
from .utils import require_api_key, make_response
from .model_runner import generate as model_generate, is_model_loaded
from .retrieval import retrieve

app = FastAPI(title="Trek-Tribe AI Service")
logger = logging.getLogger("ai-service")


class GenerateRequest(BaseModel):
    prompt: str
    max_tokens: Optional[int] = None
    top_k: Optional[int] = 3


class RetrieveRequest(BaseModel):
    query: str
    top_k: Optional[int] = 3


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/ready")
def ready():
    return {"ready": True, "model_local": MODEL_LOCAL_ENABLED, "model_loaded": is_model_loaded()}


@app.post("/retrieve")
def do_retrieve(req: RetrieveRequest, x_api_key: Optional[str] = Header(None)):
    # Lightweight retrieval endpoint (optionally protected)
    try:
        # allow unauthenticated retrieval for ease, but protect if key provided
        if AI_SERVICE_KEY:
            require_api_key(x_api_key, AI_SERVICE_KEY)
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

    q = req.query or ""
    top_k = int(req.top_k or 3)
    try:
        items = retrieve(q, top_k=top_k)
        return make_response({"retrieved": [{"score": s, "doc": d} for s, d in items]})
    except Exception as e:
        logger.exception("Retrieval failed: %s", e)
        raise HTTPException(status_code=500, detail="Retrieval failed")


@app.post("/generate")
def generate(req: GenerateRequest, x_api_key: Optional[str] = Header(None)):
    # Authenticate from backend proxy
    require_api_key(x_api_key, AI_SERVICE_KEY)

    prompt = req.prompt or ""
    max_tokens = int(req.max_tokens or 128)
    top_k = int(req.top_k or 3)

    logger.info("Generation request (tokens=%s) model_local=%s", max_tokens, MODEL_LOCAL_ENABLED)

    # Retrieval augmentation
    try:
        retrieved = retrieve(prompt, top_k=top_k) or []
    except Exception:
        retrieved = []

    if retrieved:
        # Build simple context block with sources
        contexts = []
        for score, doc in retrieved:
            txt = doc.get("text") or doc.get("excerpt") or ""
            src = doc.get("source", "unknown")
            contexts.append(f"Source: {src}\n{txt}\n---\n")
        augmented = "\n".join(contexts) + "\nUser prompt:\n" + prompt
    else:
        augmented = prompt

    try:
        text = model_generate(augmented, max_tokens=max_tokens, model_dir=MODEL_DIR, model_name=MODEL_NAME)
    except Exception as e:
        logger.exception("Generation error: %s", e)
        # Return fallback
        text = str(e)

    # Simple heuristic for ticket action (can be replaced by JSON-action prompting)
    lower = (text or "").lower()
    ticket_indicators = ["create a ticket", "contact support", "support ticket", "open a ticket", "i will create a ticket", "please contact"]
    should_create = any(t in lower for t in ticket_indicators)

    ticket_summary = None
    if should_create:
        try:
            import re
            m = re.search(r"([^.!?\n]{20,300}[.!?])", text)
            ticket_summary = m.group(1).strip() if m else (text or "")[:300]
        except Exception:
            ticket_summary = (text or "")[:300]

    payload = {"text": text, "actions": {"create_ticket": should_create, "ticket_summary": ticket_summary}}
    if retrieved:
        try:
            payload["retrieved_sources"] = [{"source": d.get("source", "unknown"), "score": float(s)} for s, d in retrieved]
        except Exception:
            payload["retrieved_sources"] = []

    return make_response(payload)
