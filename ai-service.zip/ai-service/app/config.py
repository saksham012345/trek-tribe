import os


# AI service key required by backend proxy to call this service
AI_SERVICE_KEY = os.environ.get("AI_SERVICE_KEY") or os.environ.get("AI_KEY") or ""

# Local model configuration
# MODEL_LOCAL_ENABLED: set to 'true' to force local-only inference
MODEL_LOCAL_ENABLED = os.environ.get("MODEL_LOCAL_ENABLED", "true").lower() in ("1", "true", "yes")
MODEL_NAME = os.environ.get("MODEL_NAME") or os.environ.get("AI_MODEL_NAME") or "gpt2-medium"
# Local directory where the model will be downloaded (download_model.py writes here)
MODEL_DIR = os.environ.get("MODEL_DIR") or os.environ.get("MODEL_PATH") or "/app/models/" + MODEL_NAME

# Optional PEFT adapter path (local path where adapter is saved)
AI_PEFT_ADAPTER = os.environ.get("AI_PEFT_ADAPTER") or os.environ.get("PEFT_ADAPTER") or None

# Other runtime tuning
MAX_GENERATION_TOKENS = int(os.environ.get("MAX_GENERATION_TOKENS", "256"))
