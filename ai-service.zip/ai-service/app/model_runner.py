"""
Local-only model runner for the AI microservice.

Features:
- Loads local HF model (from MODEL_DIR or MODEL_NAME) into a `transformers` pipeline.
- Optional PEFT/LoRA adapter support if `peft` is installed and `AI_PEFT_ADAPTER` is provided.
- Runs on CPU by default (device=-1). Avoids any external API calls.
- Provides a deterministic fallback generator when no model is available.
"""
from typing import Optional
import logging
import os

from . import config

logger = logging.getLogger(__name__)

_pipeline = None
_model_loaded = False


class FallbackGenerator:
    def generate(self, prompt: str, max_tokens: int = 64) -> str:
        safe = (prompt or "").strip()
        if not safe:
            return ""
        snippet = safe[: max(20, min(300, len(safe)))]
        return f"[fallback] {snippet}"


def load_local_pipeline(model_dir: Optional[str] = None, model_name: Optional[str] = None, adapter_path: Optional[str] = None):
    """Load a transformers text-generation pipeline from local files.

    model_dir: directory containing a pretrained model (weights & tokenizer).
    adapter_path: optional PEFT adapter directory to load.
    """
    global _pipeline, _model_loaded
    if _pipeline is not None:
        return _pipeline

    try:
        from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
        try:
            # PEFT is optional
            from peft import PeftModel
            _peft_available = True
        except Exception:
            PeftModel = None
            _peft_available = False

        # Resolve model location
        model_path = model_dir or model_name or config.MODEL_DIR or config.MODEL_NAME

        logger.info("Loading tokenizer from %s", model_path)
        tokenizer = AutoTokenizer.from_pretrained(model_path, use_fast=True)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        logger.info("Loading model from %s", model_path)
        model = AutoModelForCausalLM.from_pretrained(model_path, low_cpu_mem_usage=True)

        # If adapter requested and peft available, load adapter
        if adapter_path and _peft_available:
            try:
                logger.info("Loading PEFT adapter from %s", adapter_path)
                model = PeftModel.from_pretrained(model, adapter_path)
            except Exception as e:
                logger.warning("Failed to load PEFT adapter %s: %s", adapter_path, e)

        # Create pipeline on CPU (device=-1)
        _pipeline = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            device=-1,
        )
        _model_loaded = True
        logger.info("Local pipeline loaded successfully")
        return _pipeline

    except Exception as e:
        logger.exception("Failed to load local model pipeline: %s", e)
        _pipeline = None
        _model_loaded = False
        return None


def is_model_loaded() -> bool:
    return _model_loaded


def generate(prompt: str, max_tokens: int = 64, model_dir: Optional[str] = None, model_name: Optional[str] = None) -> str:
    """Generate text using local model pipeline if enabled; otherwise fallback.

    This function will attempt to load the pipeline on first call when `config.MODEL_LOCAL_ENABLED` is True.
    """
    if config.MODEL_LOCAL_ENABLED:
        try:
            adapter = config.AI_PEFT_ADAPTER
            p = load_local_pipeline(model_dir or config.MODEL_DIR, model_name or config.MODEL_NAME, adapter_path=adapter)
            if p is not None:
                # Use pipeline with generation parameters
                params = {
                    "max_new_tokens": int(max_tokens),
                    "do_sample": True,
                    "top_k": 50,
                    "top_p": 0.95,
                    "temperature": 0.8,
                }
                out = p(prompt, **params)
                # Pipeline returns list[dict], with 'generated_text'
                if isinstance(out, list) and len(out) > 0 and "generated_text" in out[0]:
                    return out[0]["generated_text"]
                # Fallback to string conversion
                return str(out)
        except Exception as e:
            logger.exception("Local generation failed: %s", e)

    # If local disabled or failed, return deterministic fallback
    return FallbackGenerator().generate(prompt, max_tokens)


__all__ = ["generate", "is_model_loaded", "load_local_pipeline"]
